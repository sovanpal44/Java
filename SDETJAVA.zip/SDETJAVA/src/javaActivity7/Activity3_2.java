package javaActivity7;

import java.util.HashSet;
import java.util.Set;

public class Activity3_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set<String> hs = new HashSet<String>();
		hs.add("A");
		hs.add("B");
		hs.add("C");
		hs.add("D");
		hs.add("E");
		hs.add("F");

		System.out.println("The size of set :" + hs.size());
		System.out.println("The element is removed :" + hs.remove("B"));

		if (hs.remove("Z")) {

			System.out.println("Z removed from set");
		}

		else {
			System.out.println("Z is not present in set");
		}

		System.out.println("This item is present in set :" + hs.contains("D"));
		System.out.println("The updated set is :" + hs);
	}

}
