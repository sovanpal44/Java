package javaActivity7;

import java.util.ArrayList;

public class Activity3_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> myList = new ArrayList<String>();

		myList.add("Sovan");
		myList.add("Promita");
		myList.add("Debojit");
		myList.add("Aparup");
		myList.add("Test");

		for (String name : myList) {

			System.out.println("The names are :" + name);
		}

		System.out.println("3 rd name is :" + myList.get(2));

		System.out.println("check if present :" + myList.contains("Sovan"));

		System.out.println("The Number of arraylist :" + myList.size());
		myList.remove(4);
		System.out.println("New size is :" + myList.size());
	}

}
