package javaActivity7;

import java.util.LinkedList;
import java.util.Queue;

public class Activity3_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Queue<Integer> q = new LinkedList<>();

		for (int i = 1; i <= 5; i++) {

			q.add(i);
		}

		System.out.println("The numbers are :" + q);
		System.out.println("Removed element is :" + q.remove());
		System.out.println("The first number is : " + q.peek());
		System.out.println("The size of queue :" + q.size());
		System.out.println("The updated queue is :" + q);

	}

}
