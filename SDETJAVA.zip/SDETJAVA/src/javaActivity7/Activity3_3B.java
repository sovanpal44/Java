package javaActivity7;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

public class Activity3_3B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Deque<String> dq = new ArrayDeque<>();

		dq.add("Dog");
		dq.addFirst("Cat");
		dq.addLast("tiger");
		dq.offer("Lion");
		dq.offerFirst("Bear");
		dq.offerLast("Deer");

		Iterator<String> iterator = dq.iterator();

		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

		System.out.println("The head element is :" + dq.peekFirst());
		System.out.println("The last elemenet is :" + dq.peekLast());
		if (dq.contains("Wolf")) {

			System.out.println("element is present");
		} else {
			System.out.println("element is not present");
		}

		System.out.println("the removed first element is :" + dq.pollFirst());
		System.out.println("the removed last element is :" + dq.pollLast());
		System.out.println("the new size is :" + dq.size());

	}

}
