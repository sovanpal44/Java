package JavaActivity2;

public class Activity2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int number[] = { 10, 20, 10, 22, 32, 20 };
		int sum = 0;
		boolean flag;
		for (int i = 0; i <= number.length - 1; i++) {

			if (number[i] == 10) {

				sum = sum + number[i];

			} else {
				continue;
			}
		}

		if (sum == 30) {
			System.out.println("The sum is 30");
			flag = true;
		} else {
			System.out.println("The sum is not 30");
			flag = false;
		}
	}

}
