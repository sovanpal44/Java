package JavaActivity1;

public class Car {

	String color;
	int make;
	int tyre;
	int doors;
	String transmission;

	public Car() {

		this.tyre = 4;
		this.doors = 4;

	}

	public void displayCharacteristics() {

		System.out.println("tyre of car is :" + tyre);
		System.out.println("doors of car is :" + doors);
		System.out.println("color of car is :" + color);
		System.out.println("transmission of car is :" + transmission);
		System.out.println("make of of car is :" + make);

	}

	public static void accelarate() {

		System.out.println("car is moving forward");

	}

	public static void brake() {

		System.out.println("car has stopped");

	}
}
