package JavaActivity1;

public class Activity1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Car carName = new Car();

		carName.color = "Black";
		carName.make = 2014;
		carName.transmission = "Manual";

		carName.displayCharacteristics();
		carName.brake();
		carName.accelarate();
	}

}
