package javaActivity5;

public class EncapsulationActivity {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		Plane plane = new Plane(10);

		plane.onboard("Sovan");
		plane.onboard("Promita");
		plane.takeOff();
		System.out.println("Plane took off at :" + plane.takeOff());
		plane.getPassesngers();
		System.out.println("People on the plane :" + plane.getPassesngers());
		Thread.sleep(5000);
		plane.land();
		System.out.println("Plane landed at :" + plane.getLastTimeLanded());
	}

}
