package javaActivity6;

public interface BicycleParts {

	public int gears = 0;
	public int speed = 0;
}
