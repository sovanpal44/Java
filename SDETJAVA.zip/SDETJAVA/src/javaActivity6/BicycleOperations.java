package javaActivity6;

public interface BicycleOperations {

	public int applyBrake(int decrement);

	public int speedUp(int increment);

}
