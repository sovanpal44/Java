package javaActivity6;

public class driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * MountainBike mountainBike = new MountainBike(5, 300, 3);
		 * 
		 * System.out.println("Mountain Bike description :" + mountainBike.bicycleDesc()); mountainBike.setHeight(4); System.out.println("Increase in speed :" +
		 * mountainBike.speedUp(5)); System.err.println("decrease in speed :" + mountainBike.applyBrake(5));
		 */

		Bicycle mbike = new MountainBike(5, 300, 3);

		System.out.println("Mountain Bike description :" + mbike.bicycleDesc());
		// mbike.setHeight(4);
		System.out.println("Increase in speed :" + mbike.speedUp(5));
		System.err.println("decrease in speed :" + mbike.applyBrake(5));

	}

}
