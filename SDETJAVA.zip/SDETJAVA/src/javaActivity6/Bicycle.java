package javaActivity6;

public class Bicycle implements BicycleOperations, BicycleParts {

	public int gears;
	public int speed;
	public int presentspeed;

	public Bicycle(int gears, int speed) {

		this.gears = gears;
		this.speed = speed;
	}

	public int applyBrake(int decrement) {
		presentspeed = speed - decrement;
		return presentspeed;
	}

	public int speedUp(int increment) {

		presentspeed = speed + increment;
		return presentspeed;
	}

	public String bicycleDesc() {

		return ("No. of gears are :" + gears + "\nSpeed of bicycle is " + speed);
	}

}
