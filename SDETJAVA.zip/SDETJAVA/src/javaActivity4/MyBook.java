package javaActivity4;

public class MyBook extends Book {

	void setTitle(String s) {
		title = s;
	}

}
