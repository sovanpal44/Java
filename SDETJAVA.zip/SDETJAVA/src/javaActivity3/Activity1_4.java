package javaActivity3;

import java.util.Arrays;

public class Activity1_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = { 50, 20, 10, 22, 32, 90 };

		for (int i = 1; i < arr.length; i++) {
			int key = arr[i];
			int j = i - 1;
			while (j >= 0 && key < arr[j]) {
				arr[j + 1] = arr[j];
				--j;
			}
			arr[j + 1] = key;
		}

		System.out.println("Sorted Array :");
		System.out.println(Arrays.toString(arr));

	}

}
